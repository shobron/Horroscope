/*
 * Object Oriented Programming Assement #2
 * Horroscope Progam
 * Dev'd by:
 * 1. Muhammad Iqbal Ardiansyah (14/365234/TK/42053)
 * 2. Muhammad Rifqi Zuliansyah (14/365235/TK/42054)
 * 3. Muflih Nadzarudin Majid   (14/368979/TK/42596)
 * 4. Muhammad Rofi Ash-Shobron (14/365237/TK/42056)
 * 5. Fata Azharuddin           (14/369641/TK/42648)
 * 6. Kharisma Prasetya         (14/365249/TK/42061) 
 * 7. F A Kristiawan            (14/365949/TK/42076)
 * 8. Nizar Akbar Meilani		(14/)
 * 
 */

This program is only made for OOP lecture assement only, held from September, 17th - 29th 2015 by lecturer Bimo Sunarfi Hantono, S.T., M.Eng.

Horroscope program is a program to display the horroscope of zodiac and shio based on date of birth (date, month, year) inputted.
It uses Java Calendar to determine the date format so it is acceptable to get the zodiac and the shio
There are there classes;
 - Main class, which is the main function of the program to call the object from another class and display the zodiac, shio, and their description
 - Compare class, which is the class to determine the shio and zodiac based on date of birth inputted
 - Ramal class, which is a class especially consisting of horroscope description of each zodiac and shio, and also the intersection of their horroscope.

Kempling Team
Copyright@2015